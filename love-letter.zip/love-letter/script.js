/* ---------------------------------------------------------
   Edit the text below to personalize each page of the letter.
   Add or remove paragraphs freely — the layout adapts.
---------------------------------------------------------- */
const PAGES = [
  {
    label: "one",
    paragraphs: [
      "Happy birthday to my bebe. ❤️ How are you? How are they treating you over there? I hope you’re doing well, even if you’re underwater right now. 😭",
      "This is the only gift I can give you for now. (It’s July 3 as I’m writing this, and I still don’t know when I should ship your care package LOL.)",
      "This is so gay, but whatever. I think you’re incredibly smart. Sometimes I lose track of what you’re saying, especially when you start talking about computers 😭, but I genuinely love listening to you. I could listen to you yap for hours because I love hearing you talk about the things you’re passionate about."
    ]
  },
  {
    label: "two",
    paragraphs: [
      "I miss your laugh. I miss your smile. I especially miss how clingy you are. I miss our conversations, our routines, and all the little things we used to do together.",
      "I’m really grateful for you and for everything you’ve done for me. Thank you for always communicating with me, even when conversations are difficult. You’re the first person who’s consistently shown me what healthy communication looks like, and that has helped me grow so much.",
      "Thank you for introducing me to new things and encouraging me to become a better person. I didn’t even realize I’d enjoy some of those things until you shared them with me. I genuinely appreciate that because you’ve helped me discover parts of myself I didn’t know were there."
    ]
  },
  {
    label: "three",
    paragraphs: [
      "This might sound weird since we’re long distance and we’ve never met in person, but I’m deeply in love with you. I know it sounds corny 😭, but it’s the truth. I don’t just like the idea of you — I love you. I want to keep building a life and a future with you, one step at a time.",
      "I know you once told me, “No promises,” and I understand why you said that. I respect that you don’t want to promise something you can’t guarantee. At the same time, I want you to know that I’m choosing you despite the distance, the waiting, and the difficult moments because none of those things have changed how I feel about you.",
      "I’m sincere about us. I’m not asking you to promise me forever. I just hope you continue choosing us too. And if one day your feelings change, I only ask that you tell me honestly instead of making me guess. That’s all I could ever ask for :)"
    ]
  },
  {
    label: "four",
    paragraphs: [
      "I was really excited when you told me you might spend New Year’s with us. I know plans change, and I understand that. I still hope that one day your ship will port in the Philippines so I can finally see you 🥲.",
      "I can’t wait for the day I get to hug you, give you lots and lots of kisses, and cuddle you instead of imagining what it would be like 😝. I love you so much, and I miss you every single day. 🤍",
      "Please stay safe. I’ll keep praying for your safety, your health, and for God to bring you home safely.",
      "Happy birthday again, bebe. ❤️",
      "— AL"
    ]
  }
];

const envelope = document.getElementById("envelope");
const sceneCover = document.getElementById("scene-cover");
const sceneLetter = document.getElementById("scene-letter");
const sceneFinale = document.getElementById("scene-finale");

const pageEyebrow = document.getElementById("pageEyebrow");
const pageText = document.getElementById("pageText");
const backBtn = document.getElementById("backBtn");
const nextBtn = document.getElementById("nextBtn");
const dotsEl = document.getElementById("dots");
const replayBtn = document.getElementById("replayBtn");
const musicBtn = document.getElementById("musicBtn");
const music = document.getElementById("music");
const heartsField = document.getElementById("heartsField");

let currentPage = 0;

// Build progress dots
PAGES.forEach((_, i) => {
  const dot = document.createElement("span");
  dot.className = "dot";
  dotsEl.appendChild(dot);
});

function renderPage(index) {
  const page = PAGES[index];
  pageEyebrow.textContent = page.label;
  pageText.innerHTML = page.paragraphs.map(p => `<p>${p}</p>`).join("");

  [...dotsEl.children].forEach((dot, i) => {
    dot.classList.toggle("active", i === index);
  });

  backBtn.disabled = index === 0;
  nextBtn.textContent = index === PAGES.length - 1 ? "finish ❤️" : "next ❤️";
}

function showScene(scene) {
  [sceneCover, sceneLetter, sceneFinale].forEach(s => (s.hidden = true));
  scene.hidden = false;
}

envelope.addEventListener("click", () => {
  envelope.classList.add("open");
  music.play().catch(() => {
    /* autoplay might be blocked or the audio file isn't present — that's fine */
  });

  setTimeout(() => {
    currentPage = 0;
    renderPage(currentPage);
    showScene(sceneLetter);
  }, 550);
});

nextBtn.addEventListener("click", () => {
  if (currentPage < PAGES.length - 1) {
    currentPage++;
    renderPage(currentPage);
  } else {
    showScene(sceneFinale);
  }
});

backBtn.addEventListener("click", () => {
  if (currentPage > 0) {
    currentPage--;
    renderPage(currentPage);
  }
});

replayBtn.addEventListener("click", () => {
  currentPage = 0;
  renderPage(currentPage);
  showScene(sceneLetter);
});

musicBtn.addEventListener("click", () => {
  if (music.paused) {
    music.play().then(() => {
      musicBtn.classList.add("playing");
      musicBtn.textContent = "🎵 pause our song";
    }).catch(() => {
      musicBtn.textContent = "🎵 add a song file to hear it";
    });
  } else {
    music.pause();
    musicBtn.classList.remove("playing");
    musicBtn.textContent = "🎵 play our song";
  }
});

// Ambient floating hearts
function spawnHeart() {
  const heart = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  heart.setAttribute("viewBox", "0 0 24 24");
  heart.classList.add("floating-heart");

  const size = 12 + Math.random() * 16;
  heart.setAttribute("width", size);
  heart.setAttribute("height", size);
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.animationDuration = `${8 + Math.random() * 6}s`;

  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("fill", "currentColor");
  path.setAttribute(
    "d",
    "M12 21s-7.5-4.6-10-9.3C.4 8.4 2 5 5.4 5c2 0 3.4 1.1 4.1 2.3C10.2 6.1 11.6 5 13.6 5 17 5 18.6 8.4 17 11.7 15.5 16.4 12 21 12 21z"
  );
  heart.appendChild(path);

  heartsField.appendChild(heart);
  setTimeout(() => heart.remove(), 15000);
}

setInterval(spawnHeart, 1400);
spawnHeart();
